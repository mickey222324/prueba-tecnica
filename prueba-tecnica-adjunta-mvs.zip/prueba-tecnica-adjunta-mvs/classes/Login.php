<?php

/**
 * Class login
 * handles the user's login and logout process
 */
class Login
{
    /**
     * @var object The database connection
     */
    private $db_connection = null;
    /**
     * @var array Collection of error messages
     */
    public $errors = array();
    /**
     * @var array Collection of success / neutral messages
     */
    public $messages = array();

    /**
     * the function "__construct()" automatically starts whenever an object of this class is created,
     * you know, when you do "$login = new Login();"
     */
    public function __construct()
    {
        // create/read session, absolutely necessary
        session_start();

        // check the possible login actions:
        // if user tried to log out (happen when user clicks logout button)
        if (isset($_GET["logout"])) {
            $this->doLogout();
        }
        // login via post data (if user just submitted a login form)
        elseif (isset($_POST["login"])) {
            $this->dologinWithPostData();
        }
    }

    /**
     * log in with post data
     */
    public function dologinWithPostData()
    {
        // check login form contents
        if (empty($_POST['usuario'])) {
            echo "usuario vacío";
        } elseif (empty($_POST['pass'])) {
            echo "Password vacío.";
        } elseif (!empty($_POST['roles']) ) {


            $user = $_POST['usuario'];
            $pass = $_POST['pass'];
            $roles = $_POST['roles'];

            //echo $user;
            //var_dump($roles);

            date_default_timezone_set("America/Mexico_City");
            setlocale(LC_TIME, 'es_MX.UTF-8');

            $date = date('Y/m/d h:i:s', time());
            //$nuevafecha = strtotime ( '+36 minute' , strtotime ( $date ) ) ;
            //$nuevafecha = date ( 'Y/m/d h:i:s a' , $nuevafecha );

            require_once ("../config/db.php");
            require_once ("../config/conexion.php");

            //$insert_lista = mysqli_query($con, "INSERT INTO sesiones (id_sesiones, user, pass, created) VALUES (NULL,'$user','$pass','$date')" );
            
            // create a database connection, using the constants from config/db.php (which we loaded in index.php)
            $this->db_connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

            // change character set to utf8 and check it
            if (!$this->db_connection->set_charset("utf8")) {
                echo $this->db_connection->error;
            }

            // if no connection errors (= working database connection)
            if (!$this->db_connection->connect_errno) {

                // escape the POST stuff
                $user_name = $this->db_connection->real_escape_string($_POST['usuario']);

                // database query, getting all the info of the selected user (allows login via email address in the
                // username field)
                $sql = "SELECT nombre, pass, rol
                        FROM usuarios
                        WHERE nombre = '".$user_name."' AND pass = '".$pass."' ;";
                $result_of_login_check = $this->db_connection->query($sql);

                //echo $result_of_login_check->num_rows;

                // if this user exists
                if ($result_of_login_check->num_rows == 1) {

                    // get result row (as an object)
                    $result_row = $result_of_login_check->fetch_object();

                    // using PHP 5.5's password_verify() function to check if the provided password fits
                    // the hash of that user's password

                    // $_SESSION['tipo'] = $result_row->tipo;
                    
                    //if (password_verify($_POST['user_password'], $result_row->user_password_hash)) {
                        // if (password_verify($_POST['user_password'], $result_row->user_password_hash) AND $_SESSION['tipo']==5) {

                        // write user data into PHP SESSION (a file on your server)
                        $_SESSION['nombre'] = $result_row->nombre;
						$_SESSION['pass'] = $result_row->pass;
						$_SESSION['rol'] = $result_row->rol;
                        $_SESSION['user_login_status'] = 1;

                        //echo $_SESSION['user_login_status'];
                        //$_SESSION['tipo'] = 0;
                        //$_SESSION['tipo'] = $result_row->tipo;

                    /*} else {
                        $this->errors[] = "Usuario y/o contraseña no coinciden.";
                    }*/
                } else {
                    //echo "Usuario y/o contraseña no coinciden.";
                    $_SESSION['user_login_status'] = 0;
                    //echo 'no';
                }
            } else {
                echo "Problema de conexión de base de datos.";
            }
        }
    }

    /**
     * perform the logout
     */
    public function doLogout()
    {
        // delete the session of the user
        $_SESSION = array();
        session_destroy();
        // return a little feeedback message
        echo "<div class='desconectado' style='position-area: center;background-color: #38b338;color: white;padding: 8px;text-align: center;'>Has sido desconectado.</div>";

    }

    /**
     * simply return the current state of the user's login
     * @return boolean user's login status
     */
    public function isUserLoggedIn()
    {
        if ($_SESSION['user_login_status'] == 1) {
            return true;
            //echo '1';
        }else{
        // default return
        return false;
        //echo '2';
        }
    }
}
