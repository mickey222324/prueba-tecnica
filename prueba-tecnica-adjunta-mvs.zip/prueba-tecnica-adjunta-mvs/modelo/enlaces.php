<?php
    class Paginas{

        public static function enlacesPaginasModelo($enlaces){

            if($enlaces == "index" || $enlaces == "home" || $enlaces == "equipo" || $enlaces == "portafolio" || $enlaces == "cv" || $enlaces == "clientes" 
            || $enlaces == "precios" || $enlaces == "contacto" || $enlaces == "admin"){

                $modulo =  "vista/modulos/".$enlaces.".php";
            
            }else if($enlaces == "home"){

                $modulo =  "vista/modulos/home.php";

            }else if($enlaces == "index"){

                $modulo =  "vista/modulos/body.php";

            }else if($enlaces == "login"){

                $modulo =  "vista/modulos/login.php";
                
            }
            
            return $modulo;
            
        }
    }
?>