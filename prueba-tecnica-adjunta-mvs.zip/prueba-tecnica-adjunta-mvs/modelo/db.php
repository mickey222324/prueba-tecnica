<?php
class Conexion
{

    public static function conectar()
    {

        $link = new PDO("mysql:host=localhost;dbname=prueba_tecnica_adjunta", "root", "");

        return $link;
    }
}