<?php

    require_once "db.php";

    class Datos extends Conexion{

        public static function vistaConsultasModel($tabla){

            $stmt = Conexion::conectar()->prepare(" SELECT * FROM $tabla ");
            $stmt->execute();
            return $stmt->fetchAll();
            $stmt->closeCursor(); 

        }

        public static function insertTaskModel($task_name){

            $stmt = Conexion::conectar()->prepare(" INSERT INTO tasks ( task_name ) VALUES ( '$task_name' ) ");
            return $stmt->execute() ? 'success' : 'error';
            $stmt->closeCursor();   

        }

        public static function updateTaskModel($editar_id,$datos){
            $stmt = Conexion::conectar()->prepare(" UPDATE portafolio SET titulo = :editar_proyecto, categoria = :editar_categoria WHERE id = '$editar_id' ");
            $stmt->bindParam(":editar_proyecto", $datos["editar_proyecto"], PDO::PARAM_STR);
            $stmt->bindParam(":editar_categoria", $datos["editar_categoria"], PDO::PARAM_STR);
            return $stmt->execute() ? 'success' : 'error';
            $stmt->closeCursor();  
        }

        public static function deleteTaskModel($datos){
            $stmt = Conexion::conectar()->prepare(" DELETE FROM tasks WHERE id = :editar_id_cliente ");
            $stmt -> bindParam(":editar_id_cliente", $datos["editar_id_cliente"], PDO::PARAM_INT);
            return $stmt->execute() ? 'success' : 'error';
            $stmt->closeCursor();  

        }

        public static function vistaProyectosModel($tabla){

            $stmt = Conexion::conectar()->prepare(" SELECT * FROM $tabla ");
            $stmt->execute();
            return $stmt->fetchAll();
            $stmt->closeCursor(); 

        }

    }

?>