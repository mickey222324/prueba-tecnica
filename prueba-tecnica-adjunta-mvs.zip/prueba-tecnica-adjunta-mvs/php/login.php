<?php 

$usuario = $_POST['usuario'];
$pass = $_POST['pass'];
$roles = $_POST['roles'];

require_once("../config/db.php");
require_once("../classes/Login.php");
$login = new Login();

$login->dologinWithPostData();
//echo $_SESSION['user_login_status'];

//echo $login->isUserLoggedIn();

if ($login->isUserLoggedIn() == 1) {
    echo '1';
} else {
    echo "<div class='msgincorrecto'>Usuario o Constraseña Incorrectos</div>";
}


//echo 'si';

?>