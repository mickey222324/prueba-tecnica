<?php
echo'
<div class="modal fade" id="ModalEditarEvento'.$item['id'].'" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel" style="color: black;font-size: 18px;">Editar Proyecto '.$item['id'].'</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <form class="needs-validation" novalidate>

                    <div class="row event-form">
                        <div class="col-md-6 col-12">
                            <div class="mb-3">
                                <label class="form-label" style="color: black;font-size: 14px;">Nombre del Proyecto</label>
                                <input class="form-control input-blanco" value="'.htmlentities($item['titulo']).'" 
                                type="text" id="editar_proyecto'.$item['id'].'" required />
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="mb-3">
                                <label class="form-label" style="color: black;font-size: 14px;">Categoría</label>
                                <input class="form-control input-blanco" value="'.htmlentities($item['categoria']).'" 
                                type="text" id="editar_categoria'.$item['id'].'" required />
                            </div>
                        </div>
                        
                    </div>


                    <div class="hstack gap-2 justify-content-end">
                        <a class="btn btn-success" style="float: right;margin-top: 25px;" onclick="editar('.$item['id'].')">Editar Proyecto</a>
                    </div>

                </form>

                

            </div>
        </div>   
    </div>
</div>
';
?>