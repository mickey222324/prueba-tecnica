<div class="row event-form">
    <div class="col-md-12 col-12">
        <div class="mb-3">
            <label class="form-label">Nombre de la Tarea</label>
            <input class="form-control" placeholder="Ingresa el Nombre de la Tarea" type="text" name="task_name" id="task_name" required value="" />
        </div>
    </div>
</div>