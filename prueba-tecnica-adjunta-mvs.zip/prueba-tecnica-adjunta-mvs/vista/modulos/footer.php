    
    <!-- Start Footer Area -->
    <div class="rn-footer-area rn-section-gap section-separator">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-area text-center">
                        <div class="logo">
                            <a href="#">
                                <img src="template/logo-vertical-dark.png" alt="logo">
                            </a>
                        </div>
                        <p class="description mt--30">© 2024. Todos los derechos reservados.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Footer Area -->
    <!-- JS ============================================ -->
    <script src="template/jquery.js.descarga"></script>
    <script src="template/modernizer.min.js.descarga"></script>
    <script src="template/feather.min.js.descarga"></script>
    <script src="template/slick.min.js.descarga"></script>
    <script src="template/bootstrap.js.descarga"></script>
    <script src="template/text-type.js.descarga"></script>
    <script src="template/wow.js.descarga"></script>
    <script src="template/aos.js.descarga"></script>
    <script src="template/particles.js.descarga"></script>
    <script src="template/jquery-one-page-nav.js.descarga"></script>
    <!-- main JS -->
    <script src="template/main.js.descarga"></script>

    <script src="assets/vendors/core/core.js"></script>
    <script src="assets/vendors/flatpickr/flatpickr.min.js"></script>
    <script src="assets/vendors/datatables.net/jquery.dataTables.js"></script>
  	<script src="assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js"></script>
	<script src="assets/vendors/feather-icons/feather.min.js"></script>
	<script src="assets/js/data-table.js"></script>

    <script>

$(function(){

    $("#loginform").on("submit", function(e){
    //var roles = document.getElementById("roles").value;
    e.preventDefault();
               
    var usuario = document.getElementById("usuario").value;
    var pass = document.getElementById("pass").value;
    var roles = document.getElementById("roles").value;

    //var roles = document.getElementById('roles');
    //var value = select.options[select.selectedIndex].value;
    //console.log(value); // en

    //alert(roles);

    var parametros = {
                "usuario" : usuario,
                "pass" : pass,
                "roles" : roles
        };
    $.ajax({
        data: parametros,
        url: "php/login.php",
        type: "POST",  
        beforeSend: function () {
           //$("#resultado").html("Procesando, espere por favor...");
        },
        success:  function (res) {
            //$("#resultado").html(res);
            $("#resultado").html(res);
                if(res == 1){
                    window.location.href = "index";
                }else{
                    $("#resultado").html(res);
                }
        }
    });
});

});

function editar(id){

$('#ModalEditarEvento'+id).modal('hide');
var editar_proyecto = document.getElementById("editar_proyecto"+id).value;
var editar_categoria = document.getElementById("editar_categoria"+id).value;

var parametros = {
            "id" : id,
            "editar_proyecto" : editar_proyecto,
            "editar_categoria" : editar_categoria
    };
$.ajax({
    data: parametros,
    url: "php/editar_registro.php",
    type: "POST", 
    beforeSend: function () {
       $("#resultado-tabla").html("Procesando, espere por favor...");
    },
    success:  function (res) {
        window.location.href = "admin";
        //$("#resultado-tabla").html(res);
    }
});
}



</script>

</body>
</html>    