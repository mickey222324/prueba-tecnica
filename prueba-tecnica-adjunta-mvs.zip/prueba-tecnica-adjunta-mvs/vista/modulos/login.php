<?php 
require_once("config/db.php");
require_once("classes/Login.php");

$login = new Login();

?>

<body class="template-color-1 spybody white-version" data-spy="scroll" data-target=".navbar-example2" data-offset="150" data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">

        <!-- Start Main Page Wrapper -->
        <main class="main-page-wrapper">

        <?php 

        $vistaDashboard = new DashboardController();
        $vistaDashboard->vistaLoginController(); 

        ?>

        </main>