<?php
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login");
	exit;
}
?>

<body class="template-color-1 spybody white-version" data-spy="scroll" data-target=".navbar-example2" data-offset="150" data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">

        <main class="main-page-wrapper">

        <?php 

        $vistaDashboard = new DashboardController();
        $vistaDashboard->vistaHeaderController();
        $vistaDashboard->vistaPopUpMobileController(); 
        //$vistaDashboard->vistaStartResumenMenuController(); 
        $vistaDashboard->vistaBackToTopStartController(); 
        $vistaDashboard->vistaGeneradorDeContenidoController(); 
        
        ?>

        </main>