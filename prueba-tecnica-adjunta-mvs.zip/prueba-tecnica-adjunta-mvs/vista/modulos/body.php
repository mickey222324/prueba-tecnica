<?php
session_start();
if (!isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] != 1) {
    header("location: login");
	exit;
}
?>

<body class="template-color-1 spybody white-version" data-spy="scroll" data-target=".navbar-example2" data-offset="150" data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">

        <!-- Start Main Page Wrapper -->
        <main class="main-page-wrapper">

        <?php 

        $vistaDashboard = new DashboardController();
        $vistaDashboard->vistaHeaderController();
        $vistaDashboard->vistaPopUpMobileController(); 
        $vistaDashboard->vistaContentController(); 
        $vistaDashboard->vistaStartServiceAreaController(); 
        $vistaDashboard->vistaStartPortafolioAreaController(); 
        $vistaDashboard->vistaStartResumenMenuController(); 
        //$vistaDashboard->vistaStartTestimoniaAreaController(); 
        $vistaDashboard->vistaStartClienteAreaController(); 
        $vistaDashboard->vistaPricingAreaController(); 
        //$vistaDashboard->vistaStartNewsAreaController(); 
        $vistaDashboard->vistaStartContactSectionController(); 
        $vistaDashboard->vistaModalPortafolioBodyAreaStartController(); 
        $vistaDashboard->vistaBlogBodyAreaStartController(); 
        $vistaDashboard->vistaBackToTopStartController(); 
        //$vistaDashboard->vistaStartRightDemoController(); 
        $vistaDashboard->vistaStartModalAreaController(); 
        
        ?>

        </main>