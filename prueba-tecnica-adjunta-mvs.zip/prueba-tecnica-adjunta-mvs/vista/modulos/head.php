<!DOCTYPE html>
<html lang="en" class=" sizes customelements history pointerevents postmessage webgl websockets cssanimations csscolumns csscolumns-width csscolumns-span csscolumns-fill csscolumns-gap csscolumns-rule csscolumns-rulecolor csscolumns-rulestyle csscolumns-rulewidth csscolumns-breakbefore csscolumns-breakafter csscolumns-breakinside flexbox picture srcset webworkers"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Content Writter || Inbio - Personal Portfolio Bootstrap-5 Template</title>
    <meta name="robots" content="noindex, follow">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="https://rainbowit.net/html/inbio/assets/images/favicon.ico">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

    <!-- CSS 
    ============================================ -->
    <link rel="stylesheet" href="template/bootstrap.min.css">
    <link rel="stylesheet" href="template/slick.css">
    <link rel="stylesheet" href="template/slick-theme.css">
    <link rel="stylesheet" href="template/aos.css">
    <link rel="stylesheet" href="template/feature.css">
    <!-- Style css -->
    <link rel="stylesheet" href="template/style.css">

    <link rel="stylesheet" href="assets/vendors/core/core.css">
	<link rel="stylesheet" href="assets/vendors/flatpickr/flatpickr.min.css">
	<link rel="stylesheet" href="assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css">
	<link rel="stylesheet" href="assets/fonts/feather-font/css/iconfont.css">
	<link rel="stylesheet" href="assets/css/style.css?v=3">
</head>