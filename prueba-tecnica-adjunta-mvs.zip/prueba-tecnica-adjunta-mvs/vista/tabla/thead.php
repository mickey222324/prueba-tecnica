<thead>
    <tr>
        <th class="pt-0">ID</th>
        <th class="pt-0">Título</th>
        <th class="pt-0">Categoría</th>
        <th class="pt-0">Imagen</th>
        <th class="pt-0"></th>
        <th class="pt-0">Acciones</th>
    </tr>
</thead>