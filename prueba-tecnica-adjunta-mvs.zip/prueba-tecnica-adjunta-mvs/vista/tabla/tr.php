<?php
echo'
<tr>
    <td>'.$item['id'].'</td>
    <td>'.htmlentities($item['titulo']).'</td>
    <td>'.htmlentities($item['categoria']).'</td>
    
    <td>
        <a class="text-white botones-acciones" href="" data-bs-toggle="modal" 
            data-bs-target="#ModalEditarEvento22'.$item['id'].'" style="padding: 8px !important;text-align: center !important;display: flex !important;">
            <image style="max-width:50px;" src="'.$item['imagen'].'" />
        </a>
    </td>

    <td>
        <span class="badge bg-success">
            <a class="text-white botones-acciones" href="" data-bs-toggle="modal" 
            data-bs-target="#ModalEditarEvento'.$item['id'].'" style="padding: 8px !important;text-align: center !important;display: flex !important;">EDITAR</a>
        </span>
    </td>
    <td>
        <span class="badge bg-danger">
        <a class="text-white" href="" style="padding: 8px !important;text-align: center !important;display: flex !important;" 
        data-bs-toggle="modal" data-bs-target="#ModalEliminarEvento'.$item['id'].'">ELIMINAR</a></span>
    </td>
</tr>
';
?>