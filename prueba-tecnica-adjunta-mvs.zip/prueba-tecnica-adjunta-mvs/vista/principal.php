<?php
	include_once "modulos/head.php";
    $mvc = new ModulosControlador();
    $mvc->enlacesPaginasControlador();
    include_once "modulos/footer.php";
?>