<?php
define("DB_HOST", "localhost");
define("DB_NAME", "prueba_tecnica_adjunta");
define("DB_USER", "root");
define("DB_PASS", "");